CSP 203 Marathon I (19 March 2018)

Individual Work Components :

 Vivek: How to parse csv file and made front end Connection of database with php Running query and interaction with database.
 		Fetching data fro database.

      2) Prasad: Scrapping data from news sites using python script & storing them in databases/ files.Scrapped data from Times and saved in 			csv file then manipulated database.

      3) Komal: Design of database schema and writing sql queries . Scrapped data from Times and saved in csv file then manipulated database. 

      4)Ram Krishna: Form creation for signup and login for user and front end part. And he also helped others.Front end homepage design.

Total work done:

We have written python code for scrapping data from website. After scrapping data we store it in a CSV file and then we extract title from CSV file. We first match the given title in database and if it already exists then we do nothing but if no row is found corresponding to the given title, then we insert title, description and read_more link in the database. 

Creating account for new user and sign up part is completely done. When a new user creates an account, data is inserted into the database table. After login user can see various news displaying on our website.




NOTE:  STARTING PAGE : rhomepage.php
